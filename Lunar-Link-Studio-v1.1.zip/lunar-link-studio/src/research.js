export const REFERENCES=[
  {id:'anser2025',title:'Sánchez-Sevilleja et al. (2025) — compact S-band antenna',url:'https://pmc.ncbi.nlm.nih.gov/articles/PMC11860546/',doi:'10.3390/s25041237',facts:'Measured stacked dual-circular-polarization patch; 80 × 80 × 6.53 mm, 30 g; 2.03 / 2.205 GHz; isolated peak gain 6.5–7 dBi. See Sections 3, 5–7. Its reported axial-ratio angular coverage is not a half-power beamwidth.'},
  {id:'tigrisat2015',title:'Nascetti et al. (2015) — Tigrisat four-patch antenna',url:'https://doi.org/10.1109/LAWP.2014.2366791',doi:'10.1109/LAWP.2014.2366791',facts:'Four patches on a 96 mm square annular board, 57 mm opening; 2.45 GHz. Reported simulated gain 7.3 dBi; measured beamwidth about 60°. Directivity 8.3 dBi must not be substituted for gain. Author manuscript: Sections II–III.'},
  {id:'patch',title:'MathWorks — rectangular patch sizing equations',url:'https://www.mathworks.com/help/antenna/ug/impedance-analysis-of-2-by-2-patch-array.html',facts:'First-pass patch dimensions using effective permittivity and fringing-field extension; final antenna behavior requires electromagnetic analysis.'},
  {id:'link',title:'MathWorks — satellite link budget',url:'https://www.mathworks.com/help/satcom/gs/satellite-link-budget.html',facts:'EIRP, free-space loss, receiver G/T, C/N₀ and Eb/N₀ form the RF calculation chain.'},
  {id:'thermal',title:'NASA — spacecraft thermal control',url:'https://www.nasa.gov/smallsat-institute/sst-soa/thermal-control/',facts:'Vacuum thermal models use radiation and conduction, without atmospheric convection.'},
  {id:'moon',title:'NASA — Moon facts',url:'https://science.nasa.gov/moon/facts/',facts:'NASA gives about +127°C in full Sun and −173°C in darkness as general surface examples. ±170°C here is the user-selected stress envelope, not a uniform lunar air temperature.'},
  {id:'slim',title:'JAXA — SLIM landing outcome, 25 January 2024',url:'https://global.jaxa.jp/press/2024/01/20240125-1_e.html',facts:'Earth communication was established after the off-attitude landing; solar power generation was the stated problem. Antenna pointing cannot restore a failed power source.'},
  {id:'astrobotic',title:'Astrobotic — Lunar Landers Payload User’s Guide',url:'https://science.nasa.gov/wp-content/uploads/2023/11/astrobotic-lunar-landers-pug.pdf',facts:'PDF p.20 describes actuated medium/high-gain antennas after touchdown; p.46 describes payload power interfaces. Steerable lander antennas are not an unprecedented invention.'}
];
export const ANTENNA_PROFILES={
  anser:{label:'INTA / ANSER reference · 2.205 GHz',source:'anser2025',values:{frequencyGHz:2.205,peakGain:6.5,beamwidth:82.44,antennaWidthMm:80,antennaHeightMm:80,antennaThicknessMm:6.53,antennaMassG:30},beamEvidence:'82.44° is an analytical approximation using the 6.5 dBi gain and assumed 65% efficiency; NOT a beamwidth measured in this paper.'},
  tigrisat:{label:'Tigrisat reference · 2.45 GHz',source:'tigrisat2015',values:{frequencyGHz:2.45,peakGain:7.3,beamwidth:60,antennaWidthMm:96,antennaHeightMm:96,antennaThicknessMm:2.1,antennaMassG:50},beamEvidence:'60° measured HPBW; 7.3 dBi simulated gain. Board thickness 2.1 mm and mass 50 g are packaging allowances, not measured values. 2.45 GHz is a comparison reference, not the proposed 2.2–2.3 GHz downlink.'}
};
export function beamMetrics(c,onAxisMargin) {
  const lambda=299792458/(c.frequencyGHz*1e9),n=Math.log(0.5)/Math.log(Math.cos(c.beamwidth*Math.PI/360));
  const directivity=2*(n+1),gain=10**(c.peakGain/10),efficiency=gain/directivity;
  const availableLoss=onAxisMargin-c.reserveDb;
  const maxMispoint=availableLoss<0?null:Math.acos(10**(-availableLoss/(10*n)))*180/Math.PI;
  return {lambdaMm:lambda*1000,n,directivityDbi:10*Math.log10(directivity),impliedEfficiency:efficiency,
    effectiveAreaCm2:gain*lambda*lambda/(4*Math.PI)*1e4,farFieldM:2*((c.antennaWidthMm/1000)**2+(c.antennaHeightMm/1000)**2)/lambda,
    halfAngle:c.beamwidth/2,lossAtHalfDegree:-10*n*Math.log10(Math.cos(0.5*Math.PI/180)),maxMispoint,
    internallyConsistent:efficiency<=1,availableLoss};
}
