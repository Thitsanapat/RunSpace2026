# Lunar Link engineering study

Model 1.1.0; generated 2026-09-19T06:08:19.396Z

## Scope
Entire payload including gimbal: 100 × 100 × 200 mm. Reduced-order simulation; not flight qualification. Antenna anser: 82.44° is an analytical approximation using the 6.5 dBi gain and assumed 65% efficiency; NOT a beamwidth measured in this paper.

## Results
- Gimbal / fixed availability: 92.23 / 17.09% of complete run
- Final gimbal / fixed margin: 8.56 / -1.28 dB
- Final pointing error: 0.0926 deg
- Obstruction: clear
- Final plate fits: true; target fits: true
- Full swept diameter: 113.33 mm
- Landing lock release: 4.340 s
- First link after release: 0.140 s; not sustained acquisition
- Sampled command latency bound: 20.00 ms; does not measure motor settling or full sensor/computation delay
- Payload / host / heater energy: 0.00507 / 0.07650 / 0.00000 Wh. Host includes payload; heater is a subset.

## Equations
FSPL = 20log10(4 pi R f/c). EIRP = 10log10(Ptx) + gain - cable loss. C/N0 = EIRP - FSPL + G/T + 228.599 - polarization - other loss. Eb/N0 = C/N0 - 10log10(bitrate). Margin = Eb/N0 - required - implementation.
Cosine power exponent 2.43403; HPBW 82.44 deg; ideal directivity 8.37 dBi; implied efficiency 65.04%. Pattern floor is -40 dB relative to peak. Imported polar cuts are axisymmetric approximations.

## Thermal and power boundary
Two nodes: payload and lander. Heater deposits heat only in lander; conduction K(Tlander-Tpayload) exchanges equal/opposite heat. Each node radiates to ground/deep space and absorbs sunlight. Requested +/-170 C is a ground boundary, not prescribed payload temperature. Host heater/RF and payload allocation are separately tracked. No solar battery recharge or full lander power model. Fixed baseline shares the host availability from this paired study.

## Limits and proposal corrections
Gimbal locks during impact and releases after rest confirmation. Body motion is prescribed, not a rigid-body contact/impact solver. Plate corner envelope does not validate cables/yokes/motors. Full swept rotation may exceed 2U. Hull is a box and ground is a plane; rocks, panels and terrain meshes do not enter obstruction. Buried antenna and lost power cannot be repaired by repointing. No shock strength, full-wave EM, complete CAD mass or lunar thermal qualification.
Known input attitude is used with bias/noise; star-tracker/IMU absolute attitude estimation is not implemented. IMU alone cannot establish absolute yaw at rest. Spring return does not make a patch omnidirectional. 50 ms command response is separate from motor settling. RF PA input is additional to the proposal's controller/motor power budget.

## Numerical method
Semi-implicit Euler 2 ms; sampled PID 100 Hz; telemetry every 40 ms. Coordinates +Y up, +Z forward; q = yaw(Y) * pitch(X) * roll(Z). Independent axes, uncoupled dynamics.

## References
- [Sánchez-Sevilleja et al. (2025) — compact S-band antenna](https://pmc.ncbi.nlm.nih.gov/articles/PMC11860546/): Measured stacked dual-circular-polarization patch; 80 × 80 × 6.53 mm, 30 g; 2.03 / 2.205 GHz; isolated peak gain 6.5–7 dBi. See Sections 3, 5–7. Its reported axial-ratio angular coverage is not a half-power beamwidth.
- [Nascetti et al. (2015) — Tigrisat four-patch antenna](https://doi.org/10.1109/LAWP.2014.2366791): Four patches on a 96 mm square annular board, 57 mm opening; 2.45 GHz. Reported simulated gain 7.3 dBi; measured beamwidth about 60°. Directivity 8.3 dBi must not be substituted for gain. Author manuscript: Sections II–III.
- [MathWorks — rectangular patch sizing equations](https://www.mathworks.com/help/antenna/ug/impedance-analysis-of-2-by-2-patch-array.html): First-pass patch dimensions using effective permittivity and fringing-field extension; final antenna behavior requires electromagnetic analysis.
- [MathWorks — satellite link budget](https://www.mathworks.com/help/satcom/gs/satellite-link-budget.html): EIRP, free-space loss, receiver G/T, C/N₀ and Eb/N₀ form the RF calculation chain.
- [NASA — spacecraft thermal control](https://www.nasa.gov/smallsat-institute/sst-soa/thermal-control/): Vacuum thermal models use radiation and conduction, without atmospheric convection.
- [NASA — Moon facts](https://science.nasa.gov/moon/facts/): NASA gives about +127°C in full Sun and −173°C in darkness as general surface examples. ±170°C here is the user-selected stress envelope, not a uniform lunar air temperature.
- [JAXA — SLIM landing outcome, 25 January 2024](https://global.jaxa.jp/press/2024/01/20240125-1_e.html): Earth communication was established after the off-attitude landing; solar power generation was the stated problem. Antenna pointing cannot restore a failed power source.
- [Astrobotic — Lunar Landers Payload User’s Guide](https://science.nasa.gov/wp-content/uploads/2023/11/astrobotic-lunar-landers-pug.pdf): PDF p.20 describes actuated medium/high-gain antennas after touchdown; p.46 describes payload power interfaces. Steerable lander antennas are not an unprecedented invention.

## Reproducibility
```json
{
  "config": {
    "scenario": "tilt",
    "duration": 18,
    "eventTime": 2,
    "rampTime": 1.5,
    "roll": 12,
    "pitch": -65,
    "yaw": 8,
    "jitter": 1,
    "jitterHz": 3,
    "jitterDuration": 3,
    "jitterDecay": 0.7,
    "restRate": 0.5,
    "restHold": 0.5,
    "landingLock": 1,
    "targetAz": 12,
    "targetEl": 25,
    "distanceKm": 384400,
    "horizon": 0,
    "azLimit": 180,
    "elMin": -85,
    "elMax": 85,
    "speedLimit": 90,
    "inertia": 0.00015,
    "movingMass": 0.15,
    "cgOffset": 0.002,
    "torqueLimit": 0.012,
    "kp": 0.08,
    "ki": 0.01,
    "kd": 0.006,
    "friction": 0.0001,
    "damping": 0.0003,
    "encoderBits": 14,
    "sensorBias": 0.05,
    "sensorNoise": 0.025,
    "controlHz": 100,
    "delayMs": 10,
    "torqueConstant": 0.025,
    "resistance": 8,
    "frequencyGHz": 2.205,
    "txPowerW": 5,
    "peakGain": 6.5,
    "beamwidth": 82.44,
    "cableLoss": 1,
    "polLoss": 0.5,
    "otherLoss": 1,
    "receiverGT": 22,
    "bitrateKbps": 4,
    "requiredEbNo": 4.5,
    "implementationLoss": 1.5,
    "reserveDb": 3,
    "antennaProfile": "anser",
    "antennaWidthMm": 80,
    "antennaHeightMm": 80,
    "antennaThicknessMm": 6.53,
    "antennaMassG": 30,
    "clearanceMm": 2,
    "mountX": 0.65,
    "mountY": 0.76,
    "mountZ": 0.73,
    "burialDepth": 0,
    "initialTemp": 15,
    "baseTemp": 15,
    "groundTemp": -40,
    "sunlight": 0.65,
    "solarIncidence": 0.5,
    "emissivity": 0.65,
    "absorptivity": 0.3,
    "thermalArea": 0.018,
    "heatCapacity": 240,
    "conductance": 0.2,
    "groundView": 0.25,
    "heaterW": 30,
    "heaterSetpoint": 0,
    "operatingMin": -40,
    "operatingMax": 80,
    "landerHeatCapacity": 3000,
    "landerArea": 0.2,
    "landerEmissivity": 0.1,
    "landerAbsorptivity": 0.15,
    "landerBatteryWh": 300,
    "heaterConnected": 1,
    "hostPower": 1,
    "hostRadio": 1,
    "busVoltage": 28,
    "regulatorEfficiency": 0.85,
    "dust": 0,
    "sealFactor": 0.25,
    "shockG": 0,
    "shockMs": 30,
    "batteryWh": 30,
    "electronicsW": 0.79,
    "rfEfficiency": 0.35,
    "jamAxis": "none",
    "pointingRequirement": 0.5,
    "seed": 2026,
    "pattern": null
  },
  "provenance": {},
  "beam": {
    "lambdaMm": 135.96029841269842,
    "n": 2.4340335586804147,
    "directivityDbi": 8.36834530600268,
    "impliedEfficiency": 0.6503774417431857,
    "effectiveAreaCm2": 65.7074108104345,
    "farFieldM": 0.18829026045745287,
    "halfAngle": 41.22,
    "lossAtHalfDegree": 0.0004025141326634337,
    "maxMispoint": 53.76010908613377,
    "internallyConsistent": true,
    "availableLoss": 5.556644452189886
  },
  "summary": {
    "samples": 9000,
    "errorSq": 3647475.631074484,
    "peakError": 66.81782244988193,
    "peakTorque": 0.012,
    "peakCurrent": 0.48,
    "goodTime": 16.602000000000775,
    "fixedGoodTime": 3.075999999999883,
    "saturationTime": 0.5600000000000004,
    "dataKbit": 66.4080000000031,
    "fixedDataKbit": 12.303999999999531,
    "rmsError": 20.13144480953583,
    "availability": 92.23333333333764,
    "fixedAvailability": 17.08888888888824,
    "energyWh": 0.005068966491651558,
    "tailRms": 0.12099712122750662,
    "settlingMs": null,
    "releaseTime": 4.339999999999744,
    "acquisitionAfterRelease": 0.13999999999998458,
    "landerEnergyWh": 0.07649753792021871,
    "heaterEnergyWh": 0,
    "commandLatencyBoundMs": 20
  }
}
```
