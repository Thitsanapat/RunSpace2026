# Validation record — 2026-09-19

Local runtime: Windows, Node.js 22.17.1, Chrome (headless browser checks).

## Completed checks

- `npm.cmd test`: 15/15 tests passed.
- `npm.cmd run build`: production build completed. Vite reports the expected approximately 508 kB uncompressed Three.js vendor chunk; runtime assets are local.
- Browser workflow passed on the production server at `http://127.0.0.1:4173`.
- Desktop viewport 1512×1120 and mobile viewport 390×844 checked; no horizontal document overflow on mobile.
- WebGL scene initialized. No browser console errors or uncaught page errors were observed.
- Exercised playback, scrubber, camera selection, exploded view, presets, numeric edits, CSV pattern import/reset, patch calculator, thermal study, controller step test, 50-trial Monte Carlo worker, report/CSV downloads, invalid config rejection and valid config import.
- Production index and example pattern endpoints returned HTTP 200.

Screenshots: `test-results/desktop.png` and `test-results/mobile.png`.

## Reproducible illustrative results

Default configuration, seed 2026, 18-second scenario, 2 ms integration. These values are simulated with assumed inputs, not measured hardware data.

| Preset | Final pointing error | Gimbal margin | Fixed margin | Gimbal link availability | Fixed link availability |
|---|---:|---:|---:|---:|---:|
| Nominal | 0.115° | 7.880 dB | 7.679 dB | 100.0% | 100.0% |
| Off-nominal landing | 0.352° | 7.879 dB | −3.558 dB | 100.0% | 16.22% |
| Hard touchdown | 0.797° | 7.876 dB | −6.343 dB | 100.0% | 15.78% |
| Dust & cold | 0.624° | 7.877 dB | −0.608 dB | 100.0% | 16.83% |
| Actuator fault | 38.074° | −2.599 dB | −3.558 dB | 16.33% | 16.22% |
| Beyond travel | 24.918° | 3.600 dB | −14.479 dB | 100.0% | 15.38% |

The travel-limited case can still retain communication because the assumed beam is broad enough. Pointing requirement and communication requirement are independent assessments. A functioning link does not imply the 0.5° pointing requirement passed.

## Separate azimuth step test

Default controller/plant/sensors, stationary base, 5° command step, ±0.5° settling band, 5 s observation, vibration/shock/jam disabled:

- Settling time: 196 ms.
- 10–90% rise time: 154 ms.
- Overshoot: approximately 1.66%.
- 50 ms target: **FAIL** under these assumptions.

The program reports this failure instead of presuming the target has been demonstrated.

## Scope of numerical validation

Tests include an independent known FSPL value (1 GHz at 1 km), a known quaternion yaw transform, half-power gain, no double-counted pointing loss, invalid input and pattern checks, deterministic seed reproduction, battery depletion, thermal heat balance and timestep refinement from 2 ms to 1 ms for a nominal disturbance case.

These checks verify implementation consistency for the covered cases. They do not validate the model against physical hardware, full-wave EM, full multibody dynamics, structural FEA or a flight thermal environment. See README and the in-app Model & evidence tab for assumptions.
