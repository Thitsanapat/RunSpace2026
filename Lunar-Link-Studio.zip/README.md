# Lunar Link Studio

โปรแกรมจำลองเสาอากาศบน gimbal ของ lunar lander พร้อมฉาก 3D, ตัวควบคุม, link budget, thermal study และ Monte Carlo ทำงานในเครื่องผ่านเบราว์เซอร์

## เปิดใช้งาน

1. ดับเบิลคลิก `START.cmd` ในโฟลเดอร์นี้ หรือ `START-LUNAR-LINK.cmd` ที่โฟลเดอร์ RunSpace
2. เปิด <http://127.0.0.1:4173> หากเบราว์เซอร์ไม่เปิดอัตโนมัติ
3. คงหน้าต่าง server ไว้ระหว่างใช้งาน ปิดด้วย Ctrl+C

เวอร์ชัน build อยู่ใน `dist/` แล้ว การเปิดผ่าน START ต้องการเพียง Node.js 22 ขึ้นไป ไม่ต้องดาวน์โหลดไลบรารีเพิ่ม และไม่เรียก CDN/API ภายนอกขณะใช้งาน

หาก port 4173 ถูกใช้ ให้ปิด server เดิมหรือใช้ PowerShell:

```powershell
$env:PORT = '4174'
node scripts/serve.mjs --open
```

## เดโมที่แนะนำ

1. เปิดแท็บ Mission overview และเลือก Off-nominal landing
2. กด Run scenario: t=2 s ยานเริ่มเอียง โดยเปลี่ยนท่าต่อเนื่อง 1.5 s
3. สังเกตเส้น target / gimbal / fixed และกราฟ link margin เสาทั้งสองใช้ RF ชุดเดียวกันและเริ่มด้วยการชี้เป้าเดียวกัน
4. หยุดหรือเลื่อนเวลาไป t=12 s เพื่ออธิบายผล ณ ขณะนั้น หมุนภาพด้วยเมาส์ ซูมด้วย scroll และเลือกมุม Gimbal เพื่อดูกลไก
5. เปลี่ยนเป็น Actuator fault เพื่อแสดงกรณีที่ระบบกู้ลิงก์ไม่ได้
6. เปิด Antenna & RF ดูตาราง budget และ radiation pattern
7. เปิด Batch analysis ทดสอบ 5° azimuth step และ Monte Carlo
8. Export run เป็น CSV, JSON, Markdown report หรือภาพ PNG ของ 3D

หน้าเว็บใช้ภาษาอังกฤษสำหรับเดโมการแข่งขัน ส่วนคำอธิบาย input สำคัญมีภาษาไทย แถบตั้งค่าบนมือถืออยู่ด้านล่างหน้าผลจำลอง

## ฟังก์ชันที่ทำงานได้

- 3D lander + gimbal สองแกน พร้อมตัวมอเตอร์, seal, patch-panel concept, solar panels และขาลงจอด
- Orbit / front / top / detail camera, exploded view, beam envelope และเส้นชี้เป้าจากผลคำนวณจริง
- 6 presets: nominal, tilted landing, hard touchdown, dust & cold, jammed actuator และ travel limit
- ตั้งค่าท่ายาน การสั่น เป้าหมาย ระยะ ช่วงมุม แรงบิด ความเร็ว inertia มวล CG และ controller
- PID, encoder quantization, sensor bias/noise, control rate และ command delay
- Torque/speed saturation, friction, gravity torque และ half-sine shock load
- Link budget เปรียบเทียบ fixed กับ gimbal: directional gain, FSPL, G/T, Eb/N0, reserve, ideal bit throughput
- Polar antenna CSV import และ first-pass rectangular patch sizing
- One-node thermal model + thermostat + energy accounting; thermal study 6, 24, 72 หรือ 336 ชั่วโมง
- Separate 5-second azimuth step test: settling band, 10–90% rise time, overshoot และเกณฑ์ 50 ms
- Seeded Monte Carlo 50–1,000 trials ใน Web Worker พร้อมยกเลิก, Wilson interval และ CSV
- Import/export scenario, full telemetry, report, screenshot และบันทึกการตั้งค่าใน local storage
- Requirement assessment ที่ระบุผลผ่าน/ไม่ผ่าน รวมถึงหัวข้อที่ยังไม่มีหลักฐาน

## ความหมายของผล

นี่คือ reduced-order engineering simulator ที่ใช้งานได้จริง ไม่ใช่เครื่องมือรับรองการบิน ค่าเริ่มต้นทั้งหมดเป็นสมมติฐาน ข้อมูลจริงที่ยังไม่มีในไฟล์ต้นทางจึงไม่ได้ถูกแต่งให้เป็นผลวัด

- มวลและ inertia เป็น input สำหรับส่วนเคลื่อนที่ ไม่ได้สกัดจาก CAD; geometry บนจอเป็นแบบสร้างด้วยโค้ด ไม่ใช่ flight CAD
- แบบจำลองแกนมอเตอร์เป็น rigid-body อิสระสองแกน ไม่มี coupled multibody/base inertial terms, structural flexibility หรือ FEA
- Target direction, distance และ environment คงที่ในแต่ละ run ไม่มี lunar ephemeris หรือ relay orbit propagation
- Hull obstruction ใช้กล่องหลักของยาน; terrain ใช้มุม horizon mask ไม่ตรวจรูปทรงทุกชิ้นส่วน
- ไม่มี full-wave EM solver: ไม่สร้าง S11/VSWR ปลอม ผล patch sizing เป็นสูตรตั้งต้น; radiation pattern ต้องนำเข้าจาก solver/การวัดหากต้องการหลักฐานของแบบจริง
- Polar pattern import สมมติความสมมาตรรอบ boresight ไม่มี asymmetric 3D pattern หรือ polarimetric model
- Dust index และ seal transmission เป็นสมมติฐาน sensitivity ไม่ใช่ความน่าจะเป็นการติดขัดที่สอบเทียบจากการทดลอง
- Actuator temperature เป็นหนึ่ง thermal node ไม่ใช่อุณหภูมิทุกชิ้นส่วน และไม่มีผล thermal expansion ต่อ pointing
- Shock input สร้าง torque pulse; ไม่ได้พิสูจน์ stress, factor of safety หรือ shock qualification
- Nominal step test ประเมิน azimuth axis เท่านั้น และคง initial temperature/physical inputs ปัจจุบัน ต้องทำ bench validation เพิ่ม
- 100% link availability ใน preset หมายถึงตามแบบจำลองและเวลา run ที่กำหนด ไม่ใช่ความน่าเชื่อถือของภารกิจจริง
- Sampled synthetic pass rates และ Wilson intervals ใช้กับ distribution ที่แสดงเท่านั้น

เมื่อแบตเตอรี่หมด ทั้งมอเตอร์/heater/RF ของชุด gimbal หยุดใช้พลังงาน ส่วน fixed baseline มี budget พลังงานของตัวเองและไม่มีการกินไฟมอเตอร์ link ถูกตัดเมื่อไม่มีไฟหรือ LOS ถูกบัง ไม่แสดง dB margin ที่ใช้งานได้ในกรณีดังกล่าว

## สมการและหน่วย

พิกัดภายใน right-handed: +Y ขึ้น, +Z ด้านหน้า; attitude quaternion = yaw(Y) × pitch(X) × roll(Z). Azimuth หมุนรอบ Y; positive elevation หมุนรอบ −X หลังการหมุน azimuth. ภายในใช้ radian, UI/CSV ใช้องศา

ต่อแกน:

```text
J * angular_acceleration = motor_torque + external_torque
                           - viscous_damping * angular_velocity
                           - Coulomb_friction

gravity = 1.625 m/s²
shock input g0 = 9.80665 m/s²
dust friction multiplier = 1 + 8 * dust * sealFactor
cold friction multiplier = 1 + max(0, 20 - temperature_C) * 0.012
```

Integrate semi-implicit Euler 2 ms, control 10–500 Hz ที่ผู้ใช้เลือก; delay ถูกส่งเข้า control tick ถัดไป; sensor noise เป็น uniform ±ค่าที่ตั้ง. PID ใช้ conditional integration ลด windup. แบบจำลอง power ใช้ PA efficiency, winding I²R และ abs(torque × speed) โดยไม่จำลอง regenerative recovery

```text
FSPL = 20 log10(4π * distance_m * frequency_Hz / c)
EIRP_dBW = 10 log10(TX_power_W) + directional_gain_dBi - TX_cable_loss
C/N0_dBHz = EIRP - FSPL + receiver_G/T + 228.599167
             - polarization_loss - other_loss
Eb/N0_dB = C/N0 - 10 log10(bitrate_bits_per_second)
link_margin_dB = Eb/N0 - required_Eb/N0 - implementation_loss
link_available = clear_LOS AND powered AND margin >= configured_reserve
```

Gain model เป็น cosine **power** pattern; full beamwidth คือมุมเต็มระหว่างจุด −3 dB. ด้านหลังและค่าต่ำมากมี floor −40 dB relative. Directional gain หักผล pointing แล้ว จึงไม่หัก pointing loss ซ้ำใน budget. Required Eb/N0 ต้องสอดคล้อง coding/modulation ที่เลือกเอง ไม่มีการบวก coding gain เพิ่ม

```text
Cthermal * dT/dt = solar_absorption + winding_heat + heater
                   + mount_conduction - net_radiation
```

ไม่มี convection ใน vacuum. Solar flux สมมติ 1361 W/m², deep-space sink 3 K; ground view factor แยกรังสีพื้นออกจากอวกาศ. Long thermal study ปิด RF/มอเตอร์ ใช้ electronics + heater จนแบตหมด; timestep 5 s; ไม่ได้จำลอง sunrise/sunset ตามสถานที่จริง

## Pattern CSV

ตัวอย่างสังเคราะห์อยู่ที่ `public/example-pattern.csv` และเปิดจากแอปได้ที่ `/example-pattern.csv` ไม่ใช่ผลวัดหรือ solver จริง

```csv
angle_deg,gain_dbi
0,12
30,6
90,-20
180,-28
```

ต้องมีอย่างน้อย 3 แถว มุมไม่ซ้ำ ครบ 0–180°; gain เป็น absolute dBi. โปรแกรม interpolate ใน dB. เมื่อ import แล้ว peak gain/beamwidth input ไม่เปลี่ยน pattern ที่นำเข้า; beam envelope บน 3D ยังเป็นภาพประกอบจาก beamwidth input ไม่ได้คำนวณใหม่จาก CSV

## โครงสร้างโค้ด

```text
src/math.js             quaternion, coordinates, seeded random, obstruction
src/engine.js           plant, control, RF, thermal, step test, patch estimate, exports
src/analysis.worker.js  Monte Carlo worker
src/scene.js            Three.js procedural scene
src/charts.js           canvas plots
src/main.js             UI, state, imports/exports, playback
src/style.css           responsive interface
tests/engine.test.js    numerical and behavioral checks
tests/browser.mjs      end-to-end Chrome checks + screenshots
scripts/serve.mjs       dependency-free local server for dist/
```

## พัฒนาต่อและทดสอบ

ใน PowerShell:

```powershell
cd C:\Users\ASUS\Desktop\RunSpace\lunar-link-studio
npm.cmd install
npm.cmd run dev
```

Dev URL: <http://127.0.0.1:5173>. ใช้ `npm.cmd` บน Windows เพื่อไม่ติด PowerShell execution policy ของ npm.ps1

```powershell
npm.cmd test
npm.cmd run build
npm.cmd start
```

Browser test ต้องมี Chrome ติดตั้งและ server เปิดอยู่:

```powershell
# ทดสอบ production server ที่เปิดด้วย npm start
$env:TEST_URL = 'http://127.0.0.1:4173'
npm.cmd run test:browser
```

ผล screenshot อยู่ใน `test-results/`. ใช้ unit checks ยืนยัน quaternion, FSPL, half-power width, ไม่มีการหัก gain ซ้ำ, occultation, deterministic runs, faults, battery, thermal balance, validation, pattern CSV, patch sizing, step response และ timestep convergence

## ที่มาหลักการ

- [MathWorks: Satellite Link Budget](https://www.mathworks.com/help/satcom/gs/satellite-link-budget.html)
- [NASA: Thermal Control](https://www.nasa.gov/smallsat-institute/sst-soa/thermal-control/)
- [NASA: Lunar Dust Mitigation Guide](https://ntrs.nasa.gov/citations/20220018746)
- [Three.js: Installation](https://threejs.org/manual/pages/installation.html)

ก่อนนำผลไปยืนยันสเปกแข่งขัน ให้แทนสมมติฐานด้วย datasheet / measured antenna pattern / CAD-derived inertia และเทียบผลกับการทดสอบจริง พร้อมเก็บ JSON + CSV + report ของ run เดียวกัน
