import { RAD, DEG, clamp, attitude, rotate, qInv, direction, angles, separation, cross, dot, rayBox, seededRandom } from './math.js';

export const MODEL_VERSION = '1.0.0';
export const DEFAULTS = Object.freeze({
  scenario: 'tilt', duration: 18, eventTime: 2, rampTime: 1.5,
  roll: 12, pitch: -38, yaw: 8, jitter: 0.3, jitterHz: 1.2,
  targetAz: 12, targetEl: 25, distanceKm: 384400, horizon: 0,
  azLimit: 170, elMin: -20, elMax: 85, speedLimit: 120,
  inertia: 0.008, movingMass: 0.42, cgOffset: 0.008, torqueLimit: 0.22,
  kp: 1.8, ki: 0.12, kd: 0.18, friction: 0.002, damping: 0.006,
  encoderBits: 14, sensorBias: 0.05, sensorNoise: 0.025,
  controlHz: 100, delayMs: 10, torqueConstant: 0.08, resistance: 2.4,
  frequencyGHz: 2.245, txPowerW: 5, peakGain: 12, beamwidth: 42,
  cableLoss: 1, polLoss: 0.5, otherLoss: 1, receiverGT: 22,
  bitrateKbps: 16, requiredEbNo: 4.5, implementationLoss: 1.5, reserveDb: 3,
  initialTemp: 15, baseTemp: -30, groundTemp: -40, sunlight: 0.65,
  solarIncidence: 0.5, emissivity: 0.65, absorptivity: 0.3, thermalArea: 0.018,
  heatCapacity: 240, conductance: 0.03, groundView: 0.25,
  heaterW: 3, heaterSetpoint: -20, operatingMin: -40, operatingMax: 80,
  dust: 0, sealFactor: 0.25, shockG: 0, shockMs: 30,
  batteryWh: 30, electronicsW: 1.2, rfEfficiency: 0.35,
  jamAxis: 'none', pointingRequirement: 0.5, seed: 2026,
  pattern: null
});

export const PRESETS = {
  nominal: { label: 'Nominal landing', thai: 'ลงจอดปกติ', note: 'A gentle touchdown. Both antennas should retain the link.', values: { roll: 3, pitch: -5, yaw: 0, jitter: 0.1, dust: 0, shockG: 0, jamAxis: 'none' } },
  tilt: { label: 'Off-nominal landing', thai: 'ยานเอียงหลังลงจอด', note: 'A 38° pitch disturbance tests link recovery and tracking.', values: { roll: 12, pitch: -38, yaw: 8, jitter: 0.3, dust: 0, shockG: 0, jamAxis: 'none' } },
  shock: { label: 'Hard touchdown', thai: 'ลงจอดกระแทก', note: 'A half-sine acceleration pulse applies a load to the offset payload.', values: { roll: 18, pitch: -42, yaw: -5, jitter: 1.1, shockG: 12, shockMs: 30, dust: 0.15, jamAxis: 'none' } },
  dust: { label: 'Dust & cold', thai: 'ฝุ่นและความเย็น', note: 'Assumed friction growth and a cold actuator stress the controller.', values: { roll: 10, pitch: -32, yaw: 15, jitter: 0.5, dust: 0.8, initialTemp: -30, sunlight: 0, baseTemp: -100, groundTemp: -130, shockG: 0, jamAxis: 'none' } },
  jam: { label: 'Actuator fault', thai: 'แกน elevation ติดขัด', note: 'The elevation axis locks at touchdown. Recovery is not guaranteed.', values: { roll: 12, pitch: -38, yaw: 8, jitter: 0.3, jamAxis: 'elevation', dust: 0, shockG: 0 } },
  limit: { label: 'Beyond travel', thai: 'เป้าหมายเกินระยะหมุน', note: 'Restricted mechanical travel exposes an unreachable target.', values: { roll: 25, pitch: 55, yaw: 20, elMax: 45, elMin: -10, azLimit: 90, jitter: 0.2, shockG: 0, jamAxis: 'none' } }
};

export const BOUNDS = {
  duration: [5,120], eventTime: [0,10], rampTime:[0.2,10], roll:[-85,85], pitch:[-85,85], yaw:[-180,180], jitter:[0,5], jitterHz:[0.1,8],
  targetAz:[-180,180], targetEl:[-10,90], distanceKm:[100,500000], horizon:[0,30], azLimit:[10,180], elMin:[-90,0], elMax:[5,90], speedLimit:[5,360],
  inertia:[0.0001,0.2], movingMass:[0.01,3], cgOffset:[0,0.2], torqueLimit:[0.005,2], kp:[0.01,20], ki:[0,5], kd:[0.001,2], friction:[0,0.1], damping:[0,0.2],
  encoderBits:[8,20], sensorBias:[-2,2], sensorNoise:[0,1], controlHz:[10,500], delayMs:[0,200], torqueConstant:[0.005,1], resistance:[0.1,20],
  frequencyGHz:[0.1,40], txPowerW:[0.01,100], peakGain:[0,35], beamwidth:[5,160], cableLoss:[0,10], polLoss:[0,30], otherLoss:[0,30], receiverGT:[-10,60],
  bitrateKbps:[0.01,10000], requiredEbNo:[-3,20], implementationLoss:[0,10], reserveDb:[0,15], initialTemp:[-150,120], baseTemp:[-200,150], groundTemp:[-200,150], sunlight:[0,1],
  solarIncidence:[0,1], emissivity:[0.01,1], absorptivity:[0.01,1], thermalArea:[0.001,0.2], heatCapacity:[10,2000], conductance:[0,1], groundView:[0,1],
  heaterW:[0,50], heaterSetpoint:[-60,30], operatingMin:[-100,0], operatingMax:[30,150], dust:[0,1], sealFactor:[0,1], shockG:[0,100], shockMs:[10,200],
  batteryWh:[0.001,500], electronicsW:[0.1,20], rfEfficiency:[0.1,0.8], pointingRequirement:[0.1,5], seed:[1,2147483647]
};

export function validateConfig(input) {
  const c = { ...DEFAULTS }, errors = [];
  for (const [key, [min,max]] of Object.entries(BOUNDS)) {
    if (input[key] === undefined) continue;
    if (typeof input[key] !== 'number' || !Number.isFinite(input[key]) || input[key] < min || input[key] > max) errors.push(`${key}: expected ${min} … ${max}`);
    else c[key] = input[key];
  }
  if (input.scenario !== undefined && !PRESETS[input.scenario]) errors.push('Unknown scenario');
  else c.scenario = input.scenario || c.scenario;
  if (input.jamAxis !== undefined && !['none','azimuth','elevation'].includes(input.jamAxis)) errors.push('Invalid jam axis');
  else c.jamAxis = input.jamAxis || 'none';
  if (input.pattern) { try { c.pattern = validatePattern(input.pattern); } catch (e) { errors.push(e.message); } }
  for (const key of ['encoderBits','controlHz','seed']) if (!Number.isInteger(c[key])) errors.push(`${key}: expected an integer`);
  if (c.eventTime >= c.duration) errors.push('Event must occur before simulation ends');
  if (errors.length) throw new Error(errors.join('\n'));
  return c;
}

export function presetConfig(id) { return { ...DEFAULTS, ...PRESETS[id].values, scenario: id }; }

export function validatePattern(rows) {
  if (!Array.isArray(rows) || rows.length < 3 || rows.length > 10000) throw new Error('Pattern requires 3–10,000 angle/gain rows');
  const data = rows.map(r => ({ angle: Number(r.angle), gain: Number(r.gain) })).sort((a,b) => a.angle-b.angle);
  if (data.some(r => !Number.isFinite(r.angle) || !Number.isFinite(r.gain) || r.angle<0 || r.angle>180 || r.gain < -150 || r.gain > 80)) throw new Error('Invalid pattern: angle 0–180°, gain −150–80 dBi');
  if (data[0].angle !== 0 || data.at(-1).angle !== 180 || data.some((r,i) => i && r.angle === data[i-1].angle)) throw new Error('Pattern must cover 0–180° with unique angles');
  return data;
}
export function parsePatternCSV(text) {
  const lines = text.trim().split(/\r?\n/).filter(l => l.trim() && !l.trim().startsWith('#'));
  if (/angle/i.test(lines[0])) lines.shift();
  return validatePattern(lines.map(l => { const [angle,gain,...extra] = l.split(','); if (extra.length || gain === undefined || !angle.trim() || !gain.trim()) throw new Error('Use two CSV columns: angle_deg,gain_dbi'); return { angle, gain }; }));
}
export function antennaGain(errorDeg, c) {
  if (c.pattern) {
    const a = clamp(errorDeg,0,180), rows = c.pattern;
    let lo = 0, hi = rows.length-1;
    while (hi-lo > 1) { const mid = (lo+hi)>>1; if (rows[mid].angle > a) hi=mid; else lo=mid; }
    const u = (a-rows[lo].angle)/(rows[hi].angle-rows[lo].angle);
    return rows[lo].gain + u*(rows[hi].gain-rows[lo].gain);
  }
  // Axisymmetric cosine POWER pattern; beamwidth is full −3 dB width.
  const n = Math.log(0.5)/Math.log(Math.cos(c.beamwidth*RAD/2));
  const cos = Math.max(0,Math.cos(errorDeg*RAD));
  return c.peakGain + Math.max(-40, cos > 0 ? 10*n*Math.log10(cos) : -40);
}
export const fspl = (ghz, km) => 20*Math.log10(4*Math.PI*km*1000*ghz*1e9/299792458);
export function linkBudget(error, c, blocked = false, powered = true) {
  const gain = antennaGain(error,c), pathLoss = fspl(c.frequencyGHz,c.distanceKm);
  const eirp = 10*Math.log10(c.txPowerW)+gain-c.cableLoss;
  const cn0 = eirp-pathLoss+c.receiverGT+228.599167-c.polLoss-c.otherLoss;
  const ebno = cn0-10*Math.log10(c.bitrateKbps*1000);
  const rawMargin = ebno-c.requiredEbNo-c.implementationLoss;
  const margin = blocked || !powered ? null : rawMargin;
  return { gain, pathLoss, eirp, cn0, ebno, margin, rawMargin,
    available: margin !== null && margin >= c.reserveDb,
    maxRateKbps: blocked || !powered ? 0 : 10**((cn0-c.requiredEbNo-c.implementationLoss-c.reserveDb)/10)/1000,
    pointingLoss: antennaGain(0,c)-gain };
}

export function bodyAt(t,c) {
  const u = clamp((t-c.eventTime)/c.rampTime,0,1), s = u*u*(3-2*u);
  const vibration = t>=c.eventTime ? c.jitter*Math.sin(2*Math.PI*c.jitterHz*(t-c.eventTime))*(1-Math.exp(-(t-c.eventTime)*3)) : 0;
  return { roll:c.roll*s+vibration*0.6, pitch:c.pitch*s+vibration, yaw:c.yaw*s,
    q: attitude(c.roll*s+vibration*0.6,c.pitch*s+vibration,c.yaw*s) };
}
export function solvePointing(q,c) {
  const target = direction(c.targetAz*RAD,c.targetEl*RAD), local = rotate(target,qInv(q));
  const desired = angles(local), command = [clamp(desired[0],-c.azLimit*RAD,c.azLimit*RAD),clamp(desired[1],c.elMin*RAD,c.elMax*RAD)];
  const blocked = c.targetEl <= c.horizon || rayBox([0,1.72,0],local,[-0.8,-0.45,-0.7],[0.8,0.65,0.7]);
  return { target,local,desired,command,blocked,reachable:separation(direction(...command),local)<1e-4 };
}
export function thermalDerivative(temp,c,motorHeat=0,heaterOn=false) {
  const sigma=5.670374419e-8, kelvin=temp+273.15, groundK=c.groundTemp+273.15;
  const absorption=clamp(c.absorptivity+0.18*c.dust,0,1);
  const solar=1361*c.sunlight*c.solarIncidence*absorption*c.thermalArea;
  const radiation=c.emissivity*sigma*c.thermalArea*(kelvin**4-c.groundView*groundK**4-(1-c.groundView)*3**4);
  const conduction=c.conductance*(c.baseTemp-temp), heater=heaterOn?c.heaterW:0;
  return { derivative:(solar+motorHeat+heater+conduction-radiation)/c.heatCapacity,solar,radiation,conduction,heater };
}

export class Simulator {
  constructor(config) {
    this.c=validateConfig(config); const c=this.c;
    this.t=0; this.axes=[{angle:clamp(c.targetAz,-c.azLimit,c.azLimit)*RAD,velocity:0,integral:0,torque:0},{angle:clamp(c.targetEl,c.elMin,c.elMax)*RAD,velocity:0,integral:0,torque:0}];
    this.temp=c.initialTemp; this.energy=0; this.fixedEnergy=0; this.heater=false;
    this.random=seededRandom(c.seed); this.nextControl=0; this.queue=[]; this.command=[this.axes[0].angle,this.axes[1].angle];
    this.stats={samples:0,errorSq:0,peakError:0,peakTorque:0,peakCurrent:0,goodTime:0,fixedGoodTime:0,saturationTime:0,dataKbit:0,fixedDataKbit:0};
  }
  step(dt=0.002) {
    const c=this.c, body=bodyAt(this.t,c), sol=solvePointing(body.q,c), powered=this.energy < c.batteryWh;
    if (this.t+1e-9 >= this.nextControl) {
      const biased=bodyAt(this.t,c); biased.q=attitude(biased.roll+c.sensorBias,biased.pitch+c.sensorBias,biased.yaw);
      const measured=solvePointing(biased.q,c).command.map(x=>x+(this.random()*2-1)*c.sensorNoise*RAD);
      this.queue.push({time:this.t+c.delayMs/1000,command:measured}); this.nextControl+=1/c.controlHz;
      while(this.queue.length && this.queue[0].time <= this.t+1e-9) this.command=this.queue.shift().command;
      this.axes.forEach((axis,i)=>{
        const quantum=2*Math.PI/(2**Math.round(c.encoderBits)), measuredAngle=Math.round(axis.angle/quantum)*quantum;
        const e=this.command[i]-measuredAngle, candidate=clamp(axis.integral+e/c.controlHz,-2,2);
        const raw=c.kp*e+c.ki*candidate-c.kd*axis.velocity;
        if(Math.abs(raw)<=c.torqueLimit || e*raw<0) axis.integral=candidate;
        axis.torque=clamp(c.kp*e+c.ki*axis.integral-c.kd*axis.velocity,-c.torqueLimit,c.torqueLimit);
      });
    }
    const coldMultiplier=1+Math.max(0,20-this.temp)*0.012;
    const friction=c.friction*(1+8*c.dust*c.sealFactor)*coldMultiplier;
    const normal=direction(this.axes[0].angle,this.axes[1].angle), lever=normal.map(x=>x*c.cgOffset);
    const grav=rotate([0,-1.625*c.movingMass,0],qInv(body.q));
    const shockU=(this.t-c.eventTime)/(c.shockMs/1000), accel=shockU>=0&&shockU<=1 ? c.shockG*9.80665*Math.sin(Math.PI*shockU) : 0;
    const load=cross(lever,[grav[0],grav[1]-c.movingMass*accel,grav[2]]);
    const azAxis=[0,1,0], elAxis=[-Math.cos(this.axes[0].angle),0,Math.sin(this.axes[0].angle)];
    const disturbance=[dot(load,azAxis),dot(load,elAxis)];
    const operational=this.temp>=c.operatingMin && this.temp<=c.operatingMax;
    let copperHeat=0,mechanicalPower=0,maxTorque=0,saturated=false;
    this.axes.forEach((axis,i)=>{
      const jammed=this.t>=c.eventTime && c.jamAxis===(i===0?'azimuth':'elevation');
      const torque=powered&&operational ? axis.torque : 0;
      axis.appliedTorque=torque; axis.jammed=jammed;
      const current=torque/c.torqueConstant;
      copperHeat+=current*current*c.resistance; mechanicalPower+=Math.abs(torque*axis.velocity);
      maxTorque=Math.max(maxTorque,Math.abs(torque));
      this.stats.peakCurrent=Math.max(this.stats.peakCurrent,Math.abs(current));
      saturated ||= Math.abs(torque)>=c.torqueLimit-1e-8;
      if(jammed) { axis.velocity=0; return; }
      let net=torque+disturbance[i]-c.damping*axis.velocity;
      if(Math.abs(axis.velocity)<1e-4 && Math.abs(net)<=friction) { axis.velocity=0; return; }
      net-=friction*Math.sign(Math.abs(axis.velocity)>1e-4?axis.velocity:net);
      axis.velocity=clamp(axis.velocity+net/c.inertia*dt,-c.speedLimit*RAD,c.speedLimit*RAD);
      axis.angle+=axis.velocity*dt;
      const min=i===0?-c.azLimit*RAD:c.elMin*RAD, max=i===0?c.azLimit*RAD:c.elMax*RAD;
      if(axis.angle<min||axis.angle>max) { axis.angle=clamp(axis.angle,min,max); axis.velocity=0; }
    });
    if(this.temp<c.heaterSetpoint-1) this.heater=true;
    if(this.temp>c.heaterSetpoint+1) this.heater=false;
    const thermal=thermalDerivative(this.temp,c,copperHeat,this.heater&&powered);
    this.temp+=thermal.derivative*dt;
    this.power=powered ? c.txPowerW/c.rfEfficiency+c.electronicsW+copperHeat+mechanicalPower+thermal.heater : 0;
    const fixedPower=this.fixedEnergy<c.batteryWh ? c.txPowerW/c.rfEfficiency+c.electronicsW : 0;
    this.energy=Math.min(c.batteryWh,this.energy+this.power*dt/3600);
    this.fixedEnergy=Math.min(c.batteryWh,this.fixedEnergy+fixedPower*dt/3600);
    this.t=Math.min(c.duration,this.t+dt);
    const frame=this.snapshot();
    this.stats.samples++; this.stats.errorSq+=frame.error**2; this.stats.peakError=Math.max(this.stats.peakError,frame.error);
    this.stats.peakTorque=Math.max(this.stats.peakTorque,maxTorque);
    if(saturated) this.stats.saturationTime+=dt;
    if(frame.link.available) { this.stats.goodTime+=dt; this.stats.dataKbit+=c.bitrateKbps*dt; }
    if(frame.fixedLink.available) { this.stats.fixedGoodTime+=dt; this.stats.fixedDataKbit+=c.bitrateKbps*dt; }
    return frame;
  }
  snapshot() {
    const c=this.c,body=bodyAt(this.t,c),sol=solvePointing(body.q,c);
    const bore=rotate(direction(this.axes[0].angle,this.axes[1].angle),body.q);
    const fixedBore=rotate(direction(c.targetAz*RAD,c.targetEl*RAD),body.q);
    const error=separation(bore,sol.target),fixedError=separation(fixedBore,sol.target);
    return {t:this.t,body,desired:sol.desired,command:sol.command,az:this.axes[0].angle,el:this.axes[1].angle,bore,fixedBore,target:sol.target,error,fixedError,
      link:linkBudget(error,c,sol.blocked,this.energy<c.batteryWh),fixedLink:linkBudget(fixedError,c,sol.blocked,this.fixedEnergy<c.batteryWh),
      blocked:sol.blocked,reachable:sol.reachable,temp:this.temp,energy:this.energy,fixedEnergy:this.fixedEnergy,power:this.power||0,
      torque:this.axes.map(a=>a.appliedTorque||0),heater:this.heater&&this.energy<c.batteryWh,
      jammed:this.axes.some(a=>a.jammed),motorOperational:this.temp>=c.operatingMin&&this.temp<=c.operatingMax,
      powered:this.energy<c.batteryWh};
  }
  summary() { const s=this.stats,t=Math.max(this.t,1e-9); return {...s,rmsError:Math.sqrt(s.errorSq/Math.max(s.samples,1)),availability:clamp(s.goodTime/t*100,0,100),fixedAvailability:clamp(s.fixedGoodTime/t*100,0,100),energyWh:this.energy}; }
}

export function runSimulation(config, sampleInterval=0.04) {
  const sim=new Simulator(config), frames=[sim.snapshot()]; let next=sampleInterval;
  while(sim.t<sim.c.duration-1e-9) {
    const f=sim.step(Math.min(0.002,sim.c.duration-sim.t));
    if(sim.t+1e-9>=next || sim.t>=sim.c.duration-1e-9) { frames.push(f); next+=sampleInterval; }
  }
  const tail=frames.filter(f=>f.t>=Math.max(sim.c.eventTime+sim.c.rampTime,sim.c.duration-3));
  // Settling is only reported for a stationary final command (no continuing vibration).
  let settlingMs=null;
  if(sim.c.jitter===0) {
    const end=sim.c.eventTime+sim.c.rampTime;
    const post=frames.filter(f=>f.t>=end); let lastBad=-1;
    post.forEach((f,i)=>{if(f.error>sim.c.pointingRequirement) lastBad=i;});
    if(post.length && lastBad<post.length-1) settlingMs=Math.max(0,(post[lastBad+1].t-end)*1000);
  }
  return {frames,summary:{...sim.summary(),tailRms:Math.sqrt(tail.reduce((s,f)=>s+f.error**2,0)/Math.max(tail.length,1)),settlingMs},config:sim.c,modelVersion:MODEL_VERSION};
}

export function patchEstimate(fGHz,er,hMm) {
  if(![fGHz,er,hMm].every(Number.isFinite)||fGHz<=0||er<=1||hMm<=0) throw new Error('Frequency and thickness must be positive; εr must exceed 1');
  const wavelength=299792458/(fGHz*1e9),h=hMm/1000;
  const width=wavelength/2*Math.sqrt(2/(er+1));
  const effectiveEr=(er+1)/2+(er-1)/2/Math.sqrt(1+12*h/width);
  const delta=0.412*h*((effectiveEr+0.3)*(width/h+0.264))/((effectiveEr-0.258)*(width/h+0.8));
  const length=wavelength/(2*Math.sqrt(effectiveEr))-2*delta;
  return {widthMm:width*1000,lengthMm:length*1000,effectiveEr,groundWidthMm:(width+6*h)*1000,groundLengthMm:(length+6*h)*1000};
}

export function runStepResponse(config,stepDeg=5) {
  if(!Number.isFinite(stepDeg)||stepDeg<=0||stepDeg>30)throw new Error('Azimuth step must be greater than 0 and at most 30°');
  const c=validateConfig({...config,duration:5,eventTime:0,roll:0,pitch:0,yaw:0,jitter:0,shockG:0,jamAxis:'none'});
  const start=c.targetAz-stepDeg;
  if(start < -c.azLimit || c.targetAz > c.azLimit || c.targetAz < -c.azLimit || c.targetEl<c.elMin || c.targetEl>c.elMax)throw new Error('Step initial/target angles must be inside mechanical travel');
  const sim=new Simulator(c);sim.axes[0].angle=start*RAD;sim.command[0]=start*RAD;
  const frames=[{t:0,angle:start,error:stepDeg,torque:0}],goal=c.targetAz;
  let maxAngle=start,t10=null,t90=null,lastOutside=0;
  while(sim.t<5-1e-9){const f=sim.step(Math.min(0.002,5-sim.t)),angle=f.az*DEG,error=Math.abs(goal-angle);frames.push({t:f.t,angle,error,torque:f.torque[0]});maxAngle=Math.max(maxAngle,angle);
    if(t10===null&&angle>=start+stepDeg*0.1)t10=f.t;
    if(t90===null&&angle>=start+stepDeg*0.9)t90=f.t;
    if(error>c.pointingRequirement)lastOutside=f.t;
  }
  const settled=frames.at(-1).error<=c.pointingRequirement,settlingMs=settled?(lastOutside+0.002)*1000:null;
  return {frames,stepDeg,initialAz:start,targetAz:goal,bandDeg:c.pointingRequirement,observationSeconds:5,
    settlingMs,riseMs:t90!==null&&t10!==null?(t90-t10)*1000:null,overshootPercent:Math.max(0,(maxAngle-goal)/stepDeg*100),
    finalError:frames.at(-1).error,passes50ms:settlingMs!==null&&settlingMs<=50,config:c};
}

export function runThermal(config,hours=24,step=5) {
  let temp=config.initialTemp,heater=false,energy=0,heaterEnergy=0; const frames=[];
  const seconds=hours*3600;
  for(let t=0;t<=seconds;t+=step) {
    if(t % Math.max(step,Math.round(seconds/180/step)*step)===0 || t===seconds) frames.push({hours:t/3600,temp,energy,heaterEnergy,powered:energy<config.batteryWh});
    if(t===seconds) break;
    if(temp<config.heaterSetpoint-1) heater=true; if(temp>config.heaterSetpoint+1) heater=false;
    const powered=energy<config.batteryWh,heat=heater&&powered?config.heaterW:0;
    const d=thermalDerivative(temp,config,0,heater&&powered);
    temp+=d.derivative*step;
    const remaining=Math.max(0,config.batteryWh-energy), consumed=powered?Math.min(remaining,(config.electronicsW+heat)*step/3600):0;
    heaterEnergy+=consumed*heat/(config.electronicsW+heat);energy+=consumed;
  }
  return {frames,minTemp:Math.min(...frames.map(f=>f.temp)),maxTemp:Math.max(...frames.map(f=>f.temp)),energyWh:energy,heaterWh:heaterEnergy};
}

export function csvExport(result) {
  const header='time_s,roll_deg,pitch_deg,yaw_deg,az_deg,el_deg,pointing_error_deg,fixed_error_deg,gimbal_margin_db,fixed_margin_db,gimbal_link_ok,fixed_link_ok,blocked,reachable,temperature_c,power_w,energy_wh,az_torque_nm,el_torque_nm';
  const rows=result.frames.map(f=>[f.t,f.body.roll,f.body.pitch,f.body.yaw,f.az*DEG,f.el*DEG,f.error,f.fixedError,f.link.margin,f.fixedLink.margin,Number(f.link.available),Number(f.fixedLink.available),Number(f.blocked),Number(f.reachable),f.temp,f.power,f.energy,...f.torque].map(v=>v===null?'':typeof v==='number'?Number(v.toFixed(6)):v).join(','));
  return header+'\n'+rows.join('\n');
}
